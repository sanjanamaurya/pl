
// class ResultHistoryModel{
//   String?id;
//   String?gamesno;
//   String?result;
//   String?status;
//   String?datetime;
//
//   ResultHistoryModel({
//     this.id,this.gamesno,this.result,this.status,this.datetime
// });
//   factory ResultHistoryModel.fromJson(Map<String, dynamic>json) => ResultHistoryModel(
//     id: json["id"].toString(),
//     gamesno: json["gamesno"].toString(),
//     result: json["result"].toString(),
//     status: json["status"].toString(),
//     datetime: json["datetime"].toString(),
//   );
// }

class ResultHistoryModel {
  final int id;
  final int? Number; // Nullable int
  final String color;
  final int gameSrNum;
  final int gameId;
  final double price;
  final int status;
  final DateTime datetime;

  ResultHistoryModel({
    required this.id,
    this.Number,
    required this.color,
    required this.gameSrNum,
    required this.gameId,
    required this.price,
    required this.status,
    required this.datetime,
  });

  factory ResultHistoryModel.fromJson(Map<String, dynamic> json) {
    return ResultHistoryModel(
      id: json['id'],
      Number: json['number'],
      color: json['color'],
      gameSrNum: json['game_sr_num'],
      gameId: json['game_id'],
      price: json['price'].toDouble(),
      status: json['status'],
      datetime: DateTime.parse(json['datetime']),
    );
  }
}

